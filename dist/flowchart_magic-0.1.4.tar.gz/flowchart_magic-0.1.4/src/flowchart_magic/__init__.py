# src/colab_flowchart/__init__.py

from .flowchart_magic import flowchart

__all__ = ["flowchart"]